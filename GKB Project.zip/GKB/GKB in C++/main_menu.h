#ifndef MAIN_MENU_H_INCLUDED
#define MAIN_MENU_H_INCLUDED
int welcome();
int main()
{
    ///MULTI_PLAYER
    //level_1();
     ///start_new_game();
    //game_menu(2);
    welcome();

    return 0;
}
#endif // MAIN_MENU_H_INCLUDED





