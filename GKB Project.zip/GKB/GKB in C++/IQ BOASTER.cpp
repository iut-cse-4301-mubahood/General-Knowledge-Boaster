#include<iostream>
#include<stdio.h>
#include<stdlib.h>    /* srand, rand */
#include<conio.h>
#include <time.h>       /* time */
using namespace std;

//A class that creates a structure of questions
class question{
public:
    string qn;
    //This string with name qn, shall  store a question.

    string opt[5];
    //This array of five strings shall contain 4 options and 1 correct answer

    string category;
    //Shall contain a category of a question

    int level;
    //Shall store a level of a question
    question(){
    }

    char correct_ans;
};


struct player{
    int id,hide;
    char name[25];
    char key[25];
    int age;
    int questions_answered[103];
    int points;
    int display;
};





//Creating a object to point at a question object memory.
question q['103'];
player player[51];

//Global variables to use in all functions
char choice;
int r;
int tested = 0;
int demo();
int quiting();
int create_acc();
int choose_acc();
int read_me();
int play(bool test);
int initializer();
int number_of_players=0;
int temp_age = 0;

int main(){
    initializer();
    demo();

    //system("cls");
    return 0;
}

int play(bool test){
    srand(time(NULL));

    if(test && tested>8){
        cout<<"You have already tested the game. Please create a players account";
        return 0;
    }


    if(test){
        while(tested<10){
            r = rand()%101;

            system("cls");

            printf("+-----------------------------------+");
            printf("\n|            DEMO PLAYER            |");
            printf("\n|            -----------            |");
            printf("\n+-----------------------------------+\n");

            printf("\n");
            cout<<q[r].qn;
            printf("\n  1. ");
            cout<<q[r].opt[0];
            printf("\n  2. ");
            cout<<q[r].opt[1];
            printf("\n  3. ");
            cout<<q[r].opt[2];
            printf("\n  4. ");
            cout<<q[r].opt[3];
            printf("\n \t");

            do{
                choice = getch();
            }
            while(choice != '1' && choice != '2' && choice != '3' && choice != '4' && choice != 27);

            if(choice == 27){
                demo();
                return 0;
            }else if((choice==q[r].correct_ans)){
                system("cls");
                system("COLOR A");
                printf("+---------------------------------+");
                printf("\n|             PERFECT!            |");
                printf("\n|            ----------           |");
                printf("\n+---------------------------------+");
                printf("\n\n");
                cout<<q[r].opt[4];
                printf("\n\n\t\t ");
                choice=getche();
                system("COLOR 7");
            }else{
                system("cls");
                system("COLOR C");
                printf("+---------------------------------+");
                printf("\n|              OOooops            |");
                printf("\n|            ----------           |");
                printf("\n+---------------------------------+");
                printf("\n\n");
                cout<<q[r].opt[4];
                printf("\n\n\t\t ");
                choice=getche();
                system("COLOR 7");
            }
            tested++;
        }
    }else{


        cout<<"Playing";
    }

    demo();
    return 0;
};


int initializer(){

    int i = 0;


    q[i].category = "alphabets";
    q[i].level=2;
    q[i].qn = "How many letters does Hawaiian alphabets have?";
    q[i].opt[0] = "21 letters.";
    q[i].opt[1] = "18 letters.";
    q[i].opt[2] = "13 letters.";
    q[i].opt[3] = "42 letters.";
    q[i].correct_ans='3';
    q[i].opt[4] = "The Hawaiian alphabets have 13 letters.";



    i++;
    q[i].category = "alphabets";
    q[i].level=1;
    q[i].qn = "Which of the following Sentences has all English Alphabets?";
    q[i].opt[0] = "the quick brown fox jumps over the lazy dog.";
    q[i].opt[1] = "The world is most wonderful place for ever.";
    q[i].opt[2] = "the quick brown fox jumps over the lazy boy.";
    q[i].opt[3] = "Non of the above.";
    q[i].correct_ans='1';
    q[i].opt[4] = " the sentence \"the quick brown fox jumps over the lazy dog uses every letter in the English alphabet.\"";

    i++;
    q[i].category = "alphabets";
    q[i].level=3;
    q[i].qn = "Which Alphabet has two syllables?";
    q[i].opt[0] = "M";
    q[i].opt[1] = "W";
    q[i].opt[2] = "Q";
    q[i].opt[3] = "X";
    q[i].correct_ans='2';
    q[i].opt[4] = "the letter W is the only letter in the alphabet that has 3 syllables (all others have 1)";

    i++;
    q[i].category = "alphabets";
    q[i].level=3;
    q[i].qn = "______Is written as 1 out 8 letters?";
    q[i].opt[0] = "E";
    q[i].opt[1] = "e";
    q[i].opt[2] = "F";
    q[i].opt[3] = "A";
    q[i].correct_ans='2';
    q[i].opt[4] = "1 out of every 8 letters written is an \"e\"";

    i++;
    q[i].category = "alphabets";
    q[i].level=2;
    q[i].qn = "How many letters does Cambodian alphabet have?";
    q[i].opt[0] = "78 letters.";
    q[i].opt[1] = "18 letters.";
    q[i].opt[2] = "13 letters.";
    q[i].opt[3] = "42 letters.";
    q[i].correct_ans='1';
    q[i].opt[4] = "The Cambodian alphabet have 74 letters.";

///ANIMALS CATEGORY =     i=4;
    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "How many teeth does a beer have?";
    q[i].opt[0] = "52.";
    q[i].opt[1] = "32.";
    q[i].opt[2] = "46.";
    q[i].opt[3] = "42.";
    q[i].correct_ans='3';
    q[i].opt[4] = "a bear has 42 teeth.";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "The eye of ___________ is bigger thank its brain.";
    q[i].opt[0] = "an ostrich";
    q[i].opt[1] = "a fish";
    q[i].opt[2] = "a man";
    q[i].opt[3] = "a hen";
    q[i].correct_ans='1';
    q[i].opt[4] = "an ostrich's eye is bigger than its brain";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "Which of the following animals needs gravity force to swallow.";
    q[i].opt[0] = "Human beings";
    q[i].opt[1] = "goats";
    q[i].opt[2] = "fish";
    q[i].opt[3] = "birds";
    q[i].correct_ans='4';
    q[i].opt[4] = "Birds need gravity to swallow.";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "How many muscles does a cat have in each ear?";
    q[i].opt[0] = "46 muscles";
    q[i].opt[1] = "32 muscles";
    q[i].opt[2] = "56 muscles";
    q[i].opt[3] = "58 muscles";
    q[i].correct_ans='2';
    q[i].opt[4] = "a cat has 32 muscles in each ear.";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "Which of the following fish can see both infrared and ultraviolet light?";
    q[i].opt[0] = "Silk fish";
    q[i].opt[1] = "Tilapia fish";
    q[i].opt[2] = "Gold fish";
    q[i].opt[3] = "Cat fish";
    q[i].correct_ans='4';
    q[i].opt[4] = "a goldfish can see both infrared and ultraviolet light.";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "What percentage does a cat spend sleeping in their life?";
    q[i].opt[0] = "20%%";
    q[i].opt[1] = "66%%";
    q[i].opt[2] = "80%%";
    q[i].opt[3] = "30%%";
    q[i].correct_ans='2';
    q[i].opt[4] = "cats spend 66% of their life asleep.";


    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "Which of the following nuts are toxic to dogs?";
    q[i].opt[0] = "Ground nuts";
    q[i].opt[1] = "Macadamica nuts";
    q[i].opt[2] = "Coco nuts";
    q[i].opt[3] = "none of the above";
    q[i].correct_ans='2';
    q[i].opt[4] = "macadamia nuts are toxic to dogs.";

    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "Spiders are in a category = of ____________.";
    q[i].opt[0] = "Arachnids";
    q[i].opt[1] = "insects";
    q[i].opt[2] = "Arthropods";
    q[i].opt[3] = "none of the above";
    q[i].correct_ans='1';
    q[i].opt[4] = "spiders are arachnids and not insects.";

    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "Which of the following animal sleeps 18 hours a day.";
    q[i].opt[0] = "Rabbit";
    q[i].opt[1] = "Dogs";
    q[i].opt[2] = "Cats";
    q[i].opt[3] = "Koala";
    q[i].correct_ans='4';
    q[i].opt[4] = "Koalas sleep around 18 hours a day.";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "How many pairs of legs do insects have?";
    q[i].opt[0] = "4";
    q[i].opt[1] = "2";
    q[i].opt[2] = "6";
    q[i].opt[3] = "3";
    q[i].correct_ans='4';
    q[i].opt[4] = "all insects have 6 legs";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "Which animal has tongue that is long enough to rich its ear?";
    q[i].opt[0] = "Giraffe";
    q[i].opt[1] = "Buffalo";
    q[i].opt[2] = "Lion";
    q[i].opt[3] = "Elephant";
    q[i].correct_ans='1';
    q[i].opt[4] = "a giraffe can clean its ears with its 21 inch tongue";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "Which of the following animals can't swallow with their eyes open?";
    q[i].opt[0] = "A frog";
    q[i].opt[1] = "A man";
    q[i].opt[2] = "A duck";
    q[i].opt[3] = "A hen";
    q[i].correct_ans='1';
    q[i].opt[4] = "frogs can't swallow with their eyes open.";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "Among all mammals, which one of these can't jump?";
    q[i].opt[0] = "A frog";
    q[i].opt[1] = "An Elephant";
    q[i].opt[2] = "A goat";
    q[i].opt[3] = "A bat";
    q[i].correct_ans='2';
    q[i].opt[4] = "elephants are the only mammal that can't jump.";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "A________can't walk without bobbing its head";
    q[i].opt[0] = "duck";
    q[i].opt[1] = "sheep";
    q[i].opt[2] = "man";
    q[i].opt[3] = "dog";
    q[i].correct_ans='1';
    q[i].opt[4] = "a duck can't walk without bobbing its head.";


    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "Which animal has killed more people in Africa than any other animal?";
    q[i].opt[0] = "Lion";
    q[i].opt[1] = "Elephant";
    q[i].opt[2] = "Leopard";
    q[i].opt[3] = "Hippopotamus";
    q[i].correct_ans='4';
    q[i].opt[4] = "hippopotamuses have killed more people in Africa than any other animal.";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "Which animal does not have upper front teeth?";
    q[i].opt[0] = "Goat";
    q[i].opt[1] = "Cow";
    q[i].opt[2] = "Leopard";
    q[i].opt[3] = "Sheep";
    q[i].correct_ans='2';
    q[i].opt[4] = "cows don't have upper front teeth.";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "Which of the following animal has a rectangular pupil?";
    q[i].opt[0] = "Crocodile";
    q[i].opt[1] = "Cow";
    q[i].opt[2] = "Octopus";
    q[i].opt[3] = "Lion";
    q[i].correct_ans='3';
    q[i].opt[4] = "an octopus pupil is rectangular.";

    i++;
    q[i].category = "animals";
    q[i].level=1;
    q[i].qn = "Which of the following animals can't move their jaws side by side?";
    q[i].opt[0] = "A camel";
    q[i].opt[1] = "Cow";
    q[i].opt[2] = "a cat";
    q[i].opt[3] = "An elephant";
    q[i].correct_ans='3';
    q[i].opt[4] = "cats can't move their jaw sideways.";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "A group of frogs id called___________.";
    q[i].opt[0] = "An army";
    q[i].opt[1] = "Crowd";
    q[i].opt[2] = "a hard";
    q[i].opt[3] = "None of the above";
    q[i].correct_ans='1';
    q[i].opt[4] = "a group of frogs is called an army.";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "A group of rhinos id called___________.";
    q[i].opt[0] = "An army";
    q[i].opt[1] = "Crowd";
    q[i].opt[2] = "a hard";
    q[i].opt[3] = "a crash";
    q[i].correct_ans='4';
    q[i].opt[4] = "a group of rhinos is called a crash.";

    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "Who invented a cat door?";
    q[i].opt[0] = "Isaac Newton";
    q[i].opt[1] = "Peter Norton";
    q[i].opt[2] = "A.B Johnathan";
    q[i].opt[3] = "None of the above";
    q[i].correct_ans='1';
    q[i].opt[4] = "Isaac Newton invented the cat door.";


    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "What is lifespan of a squirrel?";
    q[i].opt[0] = "40 years";
    q[i].opt[1] = "27 years";
    q[i].opt[2] = "9 years";
    q[i].opt[3] = "20 years";
    q[i].correct_ans='3';
    q[i].opt[4] = "the lifespan of a squirrel is 9 years.";

    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "Can a giraffe go longer than a camel,...";
    q[i].opt[0] = "No, camel goes longer than a giraffe";
    q[i].opt[1] = "Yes, giraffe goes longer than a camel";
    q[i].opt[2] = "No, They both go the same distance";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='2';
    q[i].opt[4] = "a giraffe can go longer without water than a camel.";

    i++;
    q[i].category = "animals";
    q[i].level=2;
    q[i].qn = "There are more chickens than people,...";
    q[i].opt[0] = "No, people are more than a chicken";
    q[i].opt[1] = "Yes, there are more chickens than people";
    q[i].opt[2] = "No, they both have same population";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='2';
    q[i].opt[4] = "there are more chickens than people.";

    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "What is maximum speed of a dolphin?";
    q[i].opt[0] = "60km/hr";
    q[i].opt[1] = "10Km/hr";
    q[i].opt[2] = "100Km/hr";
    q[i].opt[3] = "200Km/hr";
    q[i].correct_ans='1';
    q[i].opt[4] = "a dolphins top speed is 60kmh (37mph).";

    i++;
    q[i].category = "animals";
    q[i].level=3;
    q[i].qn = "What is maximum speed of a shark?";
    q[i].opt[0] = "60km/hr";
    q[i].opt[1] = "100Km/hr";
    q[i].opt[2] = "70Km/hr";
    q[i].opt[3] = "200Km/hr";
    q[i].correct_ans='3';
    q[i].opt[4] = "a sharks top speed is 70kmh (44mph).";

///Average questions
    i++;
    q[i].category = "average";
    q[i].level=1;
    q[i].qn = "What is the average time that a normal man falls asleep in?";
    q[i].opt[0] = "20 minutes";
    q[i].opt[1] = "7 minutes";
    q[i].opt[2] = "30 minutes";
    q[i].opt[3] = "2 minutes";
    q[i].correct_ans='2';
    q[i].opt[4] = "The average person falls asleep in 7.";

    i++;
    q[i].category = "average";
    q[i].level=1;
    q[i].qn = "What is the average percentage of water does human contain?";
    q[i].opt[0] = "20%%";
    q[i].opt[1] = "50%%";
    q[i].opt[2] = "30%%";
    q[i].opt[3] = "78%%";
    q[i].correct_ans='4';
    q[i].opt[4] = "The average human brain contains around 78% water.";

    i++;
    q[i].category = "average";
    q[i].level=1;
    q[i].qn = "How many times does an average person laugh per day?";
    q[i].opt[0] = "50 times";
    q[i].opt[1] = "90 times ";
    q[i].opt[2] = "10 times";
    q[i].opt[3] = "70 times";
    q[i].correct_ans='3';
    q[i].opt[4] = " the average person laughs 10 times a day.";

    i++;
    q[i].category = "average";
    q[i].level=1;
    q[i].qn = "What is the average lifespan of a mosquito?";
    q[i].opt[0] = "3 weeks";
    q[i].opt[1] = "2 weeks";
    q[i].opt[2] = "2 days";
    q[i].opt[3] = "1 month";
    q[i].correct_ans='2';
    q[i].opt[4] = " the average life span of a mosquito is 2 weeks";

    i++;
    q[i].category = "average";
    q[i].level=1;
    q[i].qn = "What is the average weight of skin a person shades off in a year?";
    q[i].opt[0] = "3Kg";
    q[i].opt[1] = "20Kg";
    q[i].opt[2] = "250g";
    q[i].opt[3] = "700g";
    q[i].correct_ans='4';
    q[i].opt[4] = "The average person sheds .7kg (1.5 pounds) of skin each year";

    ///BRANDS
    i++;
    q[i].category = "brands";
    q[i].level=2;
    q[i].qn = "Which of the following carbonated drinks originally contained cocaine?";
    q[i].opt[0] = "Mirinda";
    q[i].opt[1] = "Coca-cola";
    q[i].opt[2] = "Fanta";
    q[i].opt[3] = "Pepsi-cola";
    q[i].correct_ans='2';
    q[i].opt[4] = "Coca-Cola originally contained cocaine.";

    i++;
    q[i].category = "brands";
    q[i].level=2;
    q[i].qn = "How many stars are found in the Paramount Studios logo?";
    q[i].opt[0] = "22";
    q[i].opt[1] = "41";
    q[i].opt[2] = "33";
    q[i].opt[3] = "10";
    q[i].correct_ans='1';
    q[i].opt[4] = "there are 22 stars in the Paramount studios logo.";

    i++;
    q[i].category = "brands";
    q[i].level=2;
    q[i].qn = "When did Coca cola launched its second product spite?";
    q[i].opt[0] = "1990";
    q[i].opt[1] = "2000";
    q[i].opt[2] = "1961";
    q[i].opt[3] = "1980";
    q[i].correct_ans='3';
    q[i].opt[4] = "Coca Cola launched its 3rd product Sprite in 1961.";

    i++;
    q[i].category = "brands";
    q[i].level=2;
    q[i].qn = "What was the previous name of MasterCard?";
    q[i].opt[0] = "MasterCharge";
    q[i].opt[1] = "MasterPoster";
    q[i].opt[2] = "Twitter";
    q[i].opt[3] = "MasterDelivery";
    q[i].correct_ans='1';
    q[i].opt[4] = "MasterCard was originally called MasterCharge.";

    i++;
    q[i].category = "brands";
    q[i].level=3;
    q[i].qn = "What was the first product to have a bar-code?";
    q[i].opt[0] = "Mobile Telephone";
    q[i].opt[1] = "Parked soap";
    q[i].opt[2] = "Wrigley's gum";
    q[i].opt[3] = "A computer";
    q[i].correct_ans='3';
    q[i].opt[4] = "the first product to have a bar code was Wrigley's gum.";

    i++;
    q[i].category = "brands";
    q[i].level=3;
    q[i].qn = "Who was the founder of Coca Cola?";
    q[i].opt[0] = "Fracklin J";
    q[i].opt[1] = "Parked soap";
    q[i].opt[2] = "Willy Swatz";
    q[i].opt[3] = "Joseph A Biedenharn";
    q[i].correct_ans='4';
    q[i].opt[4] = "Coca Cola was founded by Joseph A Biedenharn.";

    i++;
    q[i].category = "brands";
    q[i].level=3;
    q[i].qn = "How did credit card idea came into existence?";
    q[i].opt[0] = "Because of Government issues";
    q[i].opt[1] = "It was invented by bank.";
    q[i].opt[2] = "It was a Diner's Club card issue.";
    q[i].opt[3] = "None of the above";
    q[i].correct_ans='3';
    q[i].opt[4] = "the original name of Bank of America was Bank of Italy";

    i++;
    q[i].category = "brands";
    q[i].level=3;
    q[i].qn = "What was the original name of Bank of America?";
    q[i].opt[0] = "Bank of Italy";
    q[i].opt[1] = "London Bank.";
    q[i].opt[2] = "Bank of U.S";
    q[i].opt[3] = "None of the above";
    q[i].correct_ans='1';
    q[i].opt[4] = "the original name of Bank of America was Bank of Italy.";

//CAN'T
    i++;
    q[i].category = "cant";
    q[i].level=3;
    q[i].qn = "If food is not mixed up with saliva, you can't feel its test.";
    q[i].opt[0] = "True.";
    q[i].opt[1] = "FALSE.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "unless food is mixed with saliva you can't taste it.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "the cheetah is the only cat that can retract it's claws";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='2';
    q[i].opt[4] = "the cheetah is the only cat that can't retract it's claws.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "roosters can't crow if they can't fully extend their necks";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "roosters can't crow if they can't fully extend their necks.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "a crocodile can't move its tongue";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "a crocodile can't move its tongue.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "whales can swim backwards";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='2';
    q[i].opt[4] = "whales can't swim backwards.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "giraffes can swim";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='2';
    q[i].opt[4] = "giraffes can't swim.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = " snakes can't bite in rivers or swamps (they would drown otherwise)";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "Yes!, snakes can't bite in rivers or swamps (they would drown otherwise).";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "giraffes can't cough";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "Yes!, giraffes can't cough.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "you can't tickle yourself and then laugh because of that tickle";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "you can't tickle yourself.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "At which age can a lion start roaring?";
    q[i].opt[0] = "1 year";
    q[i].opt[1] = "2 years";
    q[i].opt[2] = "5 years";
    q[i].opt[3] = "10 years";
    q[i].correct_ans='2';
    q[i].opt[4] = "lion's can't roar until the age of 2 years.";

    i++;
    q[i].category = "cant";
    q[i].level=2;
    q[i].qn = "Is it possible for you to trademark your surname?";
    q[i].opt[0] = "Yes.";
    q[i].opt[1] = "No.";
    q[i].opt[2] = "None of these options";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='2';
    q[i].opt[4] = "you can't trademark surnames.";

///color
    i++;
    q[i].category = "colour";
    q[i].level=2;
    q[i].qn = "What is the colour of a lobster's blood?";
    q[i].opt[0] = "Green";
    q[i].opt[1] = "Yellow";
    q[i].opt[2] = "Colourless";
    q[i].opt[3] = "Red";
    q[i].correct_ans='3';
    q[i].opt[4] = "a lobsters blood is colorless but when exposed to oxygen it turns blue.";

///Counties ???????
    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "How many rivers are found in Jamaica?";
    q[i].opt[0] = "50 rivers";
    q[i].opt[1] = "100 rivers";
    q[i].opt[2] = "120 rivers";
    q[i].opt[3] = "20 rivers";
    q[i].correct_ans='3';
    q[i].opt[4] = "Jamaica has 120 rivers.";

    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "Which country 70% of all toys in the world?";
    q[i].opt[0] = "America";
    q[i].opt[1] = "China";
    q[i].opt[2] = "England";
    q[i].opt[3] = "Saudi Arabia";
    q[i].correct_ans='2';
    q[i].opt[4] = "China manufacturers 70% of the worlds toys.";


    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "Which country did paper originated from?";
    q[i].opt[0] = "America";
    q[i].opt[1] = "China";
    q[i].opt[2] = "England";
    q[i].opt[3] = "Saudi Arabia";
    q[i].correct_ans='2';
    q[i].opt[4] = "China manufacturers 70% of the worlds toys.";

    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "Which country did wheelbarrow originated from?";
    q[i].opt[0] = "America";
    q[i].opt[1] = "India";
    q[i].opt[2] = "South Africa";
    q[i].opt[3] = "China";
    q[i].correct_ans='4';
    q[i].opt[4] = "the wheelbarrow is invented in China.";

    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "Which country has most post offices in the world than any other country?";
    q[i].opt[0] = "America";
    q[i].opt[1] = "India";
    q[i].opt[2] = "South Africa";
    q[i].opt[3] = "China";
    q[i].correct_ans='2';
    q[i].opt[4] = " India has the most post offices than any other country (over 100,000).";


    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "Which of the following countries boarders 9 countries?";
    q[i].opt[0] = "Uganda";
    q[i].opt[1] = "India";
    q[i].opt[2] = "Egypt";
    q[i].opt[3] = "Germany";
    q[i].correct_ans='4';
    q[i].opt[4] = "Germany borders 9 other countries.";

    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "Peru has more pyramids than Egypt.";
    q[i].opt[0] = "True";
    q[i].opt[1] = "False";
    q[i].opt[2] = "No one knows";
    q[i].opt[3] = "None of the above";
    q[i].correct_ans='4';
    q[i].opt[4] = "it's true, Peru has more pyramids than Egypt.";

    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "In which country is the most smallest bird found.";
    q[i].opt[0] = "Cuba";
    q[i].opt[1] = "India";
    q[i].opt[2] = "Bangladesh";
    q[i].opt[3] = "Togo";
    q[i].correct_ans='1';
    q[i].opt[4] = "the worlds smallest bird is the 'bee hummingbird' found in Cuba.";


    i++;
    q[i].category = "countries";
    q[i].level=2;
    q[i].qn = "How many strips are found in United States of America National flag.";
    q[i].opt[0] = "11";
    q[i].opt[1] = "21";
    q[i].opt[2] = "13";
    q[i].opt[3] = "8";
    q[i].correct_ans='3';
    q[i].opt[4] = "the US flag has 13 stripes (representing the original 13 states).";

///DISTANCE
    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "Where is the longest street found?";
    q[i].opt[0] = "In china";
    q[i].opt[1] = "New-York";
    q[i].opt[2] = "Dubai";
    q[i].opt[3] = "Canada";
    q[i].correct_ans='4';
    q[i].opt[4] = "the longest street in the world is Yonge street in Toronto Canada measuring 1,896 km (1,178 miles).";

    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "Does sound travel faster in water than in air?";
    q[i].opt[0] = "Yes";
    q[i].opt[1] = "No";
    q[i].opt[2] = "There is no difference";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "sound travels 4.3 times faster through water than in air";


    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "What is the moon's diameter?";
    q[i].opt[0] = "500km";
    q[i].opt[1] = "3021km";
    q[i].opt[2] = "3476km";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='3';
    q[i].opt[4] = "the Moons diameter is 3,476km";

    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "What is the diameter of planet Jupiter?";
    q[i].opt[0] = "152,800km";
    q[i].opt[1] = "3021km";
    q[i].opt[2] = "3476";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "the diameter of Jupiter is 152,800km (88 700 miles)";


    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "What is the diameter of the sun?";
    q[i].opt[0] = "152,800km";
    q[i].opt[1] = "3021km";
    q[i].opt[2] = "3476";
    q[i].opt[3] = "1,390,176km";
    q[i].correct_ans='4';
    q[i].opt[4] = "the Sun has a diameter of 1,390,176km (864,000miles)";

    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "What is the diameter of the earth?";
    q[i].opt[0] = "12,756 km";
    q[i].opt[1] = "3021km";
    q[i].opt[2] = "3476km";
    q[i].opt[3] = "1,390,176km";
    q[i].correct_ans='1';
    q[i].opt[4] = "the diameter of Earth is 12,756 km (7,926 miles).";

    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "How long can a dolphin detect sound in water?";
    q[i].opt[0] = "127 km";
    q[i].opt[1] = "302 km";
    q[i].opt[2] = "24 km";
    q[i].opt[3] = "1,176km";
    q[i].correct_ans='3';
    q[i].opt[4] = "dolphin's can detect underwater sounds from 24 km (15 miles) away.";

    i++;
    q[i].category = "distance";
    q[i].level=2;
    q[i].qn = "How long can the sun penetrate through clean water?";
    q[i].opt[0] = "73m";
    q[i].opt[1] = "31m";
    q[i].opt[2] = "97,m";
    q[i].opt[3] = "191m";
    q[i].correct_ans='1';
    q[i].opt[4] = "sun light can penetrate clean ocean water up to a depth of 73m (240 feet).";

///drinks
    i++;
    q[i].category = "drinks";
    q[i].level=2;
    q[i].qn = "Where did beer made from bananas originated from?";
    q[i].opt[0] = "America";
    q[i].opt[1] = "Africa";
    q[i].opt[2] = "Asia";
    q[i].opt[3] = "Australia";
    q[i].correct_ans='2';
    q[i].opt[4] = "Beer made from bananas was originated fromAfrica.";

    i++;
    q[i].category = "drinks";
    q[i].level=2;
    q[i].qn = "Where did beer made from bananas originated from?";
    q[i].opt[0] = "America";
    q[i].opt[1] = "Africa";
    q[i].opt[2] = "Asia";
    q[i].opt[3] = "Australia";
    q[i].correct_ans='2';
    q[i].opt[4] = "Beer made from bananas was originated fromAfrica.";

///english
    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "What is the most used word in English conversation?";
    q[i].opt[0] = "I";
    q[i].opt[1] = "is";
    q[i].opt[2] = "yes";
    q[i].opt[3] = "ok";
    q[i].correct_ans='1';
    q[i].opt[4] = " the most commonly used word in English conversation is 'I'.";

    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "What is the longest English word with most of its letters arranged in alphabetical order?";
    q[i].opt[0] = "Almost";
    q[i].opt[1] = "Abduct";
    q[i].opt[2] = "Abandon";
    q[i].opt[3] = "Alphabets";
    q[i].correct_ans='1';
    q[i].opt[4] = "the word 'almost' is the longest in the English language with all the letters in alphabetical order.";

    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "Which language do all pilots in the world use to identify themselves no matter what country the come from?";
    q[i].opt[0] = "English";
    q[i].opt[1] = "Chinese";
    q[i].opt[2] = "French";
    q[i].opt[3] = "German";
    q[i].correct_ans='1';
    q[i].opt[4] = "all pilots on international flights identify themselves in English regardless of their country of origin.";

    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "When was the first English dictionary written?";
    q[i].opt[0] = "in 1980";
    q[i].opt[1] = "in 1860";
    q[i].opt[2] = "in 1755";
    q[i].opt[3] = "in 1680";
    q[i].correct_ans='3';
    q[i].opt[4] = "The first English dictionary was written in 1755.";

    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "How do we call the dot on top of letter 'i'?";
    q[i].opt[0] = "a dot";
    q[i].opt[1] = "a little";
    q[i].opt[2] = "a pinch";
    q[i].opt[3] = "a dangle";
    q[i].correct_ans='2';
    q[i].opt[4] = "The dot on top of the letter 'i' is called a tittle.";

    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "What is the longest English word that uses a single vowel?";
    q[i].opt[0] = "me";
    q[i].opt[1] = "little";
    q[i].opt[2] = "strength";
    q[i].opt[3] = "pot";
    q[i].correct_ans='2';
    q[i].opt[4] = "the word 'Strengths' is the longest word in the English language with just one vowel.";

    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "What is the oldest English word?";
    q[i].opt[0] = "God";
    q[i].opt[1] = "little";
    q[i].opt[2] = "Food";
    q[i].opt[3] = "town";
    q[i].correct_ans='4';
    q[i].opt[4] = "the oldest word in the English language is 'town'.";


    i++;
    q[i].category = "english";
    q[i].level=2;
    q[i].qn = "How many words in English language ends with letters 'dous'?";
    q[i].opt[0] = "8 words";
    q[i].opt[1] = "20 words";
    q[i].opt[2] = "10 words";
    q[i].opt[3] = "4 words";
    q[i].correct_ans='4';
    q[i].opt[4] = "there are only 4 words in the English language which end in 'dous' (they are: hazardous, horrendous, stupendous and tremendous).";

///people
    i++;
    q[i].category = "people";
    q[i].level=2;
    q[i].qn = "At what age did Bill Gates begin programming computers?";
    q[i].opt[0] = "8";
    q[i].opt[1] = "19";
    q[i].opt[2] = "10";
    q[i].opt[3] = "13";
    q[i].correct_ans='4';
    q[i].opt[4] = "Bill Gates began programming computers at the of age 13.";

    i++;
    q[i].category = "people";
    q[i].level=2;
    q[i].qn = "How many hours did Einstein used to sleep for a night?";
    q[i].opt[0] = "8";
    q[i].opt[1] = "19";
    q[i].opt[2] = "10";
    q[i].opt[3] = "13";
    q[i].correct_ans='3';
    q[i].opt[4] = "Einstein slept 10 hours a night.";

    i++;
    q[i].category = "people";
    q[i].level=2;
    q[i].qn = "How old was Sir Isaac Newton when he discovered gravitational force?";
    q[i].opt[0] = "35";
    q[i].opt[1] = "30";
    q[i].opt[2] = "10";
    q[i].opt[3] = "23";
    q[i].correct_ans='4';
    q[i].opt[4] = "Sir Isaac Newton was 23 when he discovered the law of gravity.";

    i++;
    q[i].category = "people";
    q[i].level=2;
    q[i].qn = "Who invented a word 'Assassination'?";
    q[i].opt[0] = "Isaac Newton";
    q[i].opt[1] = "Shakespeare";
    q[i].opt[2] = "Johnson K.";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='2';
    q[i].opt[4] = "Shakespeare invented the words 'assassination' and 'bump'.";

    i++;
    q[i].category = "people";
    q[i].level=2;
    q[i].qn = "How long did Leonardo Da Vinci took to paint Mona Lisa?";
    q[i].opt[0] = "10 years";
    q[i].opt[1] = "5 years";
    q[i].opt[2] = "12 months";
    q[i].opt[3] = "15 years";
    q[i].correct_ans='1';
    q[i].opt[4] = "it took Leonardo Da Vinci 10 years to paint Mona Lisa";

    i++;
    q[i].category = "people";
    q[i].level=2;
    q[i].qn = "Did Albert Einstein new how to drive a car?";
    q[i].opt[0] = "Yes he knew";
    q[i].opt[1] = "No he didn't know";
    q[i].opt[2] = "No one knows the real answer";
    q[i].opt[3] = "none of these options is correct.";
    q[i].correct_ans='1';
    q[i].opt[4] = "Albert Einstein never knew how to drive a car";

///first
    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "When was the first Telephone Phonebook made?";
    q[i].opt[0] = "in 1990";
    q[i].opt[1] = "in 1800";
    q[i].opt[2] = "in 1870";
    q[i].opt[3] = "none of these options is correct.";
    q[i].correct_ans='2';
    q[i].opt[4] = "in 1878 the first telephone book made contained only 50 names";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "What was the maximum number of contacts could first Telephone Phonebook save?";
    q[i].opt[0] = "10 contacts";
    q[i].opt[1] = "5 contacts";
    q[i].opt[2] = "100 contacts";
    q[i].opt[3] = "50 contacts.";
    q[i].correct_ans='4';
    q[i].opt[4] = "in 1878 the first telephone book made contained only 50 names";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "Which country used paper money for the first time?";
    q[i].opt[0] = "China";
    q[i].opt[1] = "America";
    q[i].opt[2] = "India";
    q[i].opt[3] = "Egypt.";
    q[i].correct_ans='1';
    q[i].opt[4] = "paper money was first used in China";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "Which was the first country to use postage stamp?";
    q[i].opt[0] = "China";
    q[i].opt[1] = "America";
    q[i].opt[2] = "Britain";
    q[i].opt[3] = "Egypt.";
    q[i].correct_ans='3';
    q[i].opt[4] = "Britain was the first country to use postage stamps";


    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "Which was the first country to legalize abortion?";
    q[i].opt[0] = "Iceland";
    q[i].opt[1] = "America";
    q[i].opt[2] = "Britain";
    q[i].opt[3] = "Egypt.";
    q[i].correct_ans='1';
    q[i].opt[4] = "Iceland was the first country to legalise abortion in 1935";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "When were the first foods introduced?";
    q[i].opt[0] = "in 1920";
    q[i].opt[1] = "in 1980";
    q[i].opt[2] = "in 1999";
    q[i].opt[3] = "in 1990";
    q[i].correct_ans='1';
    q[i].opt[4] = "the frozen foods were first introduced in the 1920.";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "When were the first toothbrush invented?";
    q[i].opt[0] = "in 1920";
    q[i].opt[1] = "in 1498";
    q[i].opt[2] = "in 1680";
    q[i].opt[3] = "in 1999";
    q[i].correct_ans='2';
    q[i].opt[4] = "the first toothbrush was invented in 1498.";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "What was the first movie tittle for James Bond's movie?";
    q[i].opt[0] = "Dr. No.";
    q[i].opt[1] = "The puzzle";
    q[i].opt[2] = "Wheels on meals";
    q[i].opt[3] = "The expendibles";
    q[i].correct_ans='1';
    q[i].opt[4] = "the first James Bond movie was called 'Dr. No'.";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "When did the first puzzle appear?";
    q[i].opt[0] = "In 1990";
    q[i].opt[1] = "1913";
    q[i].opt[2] = "2000";
    q[i].opt[3] = "1900";
    q[i].correct_ans='2';
    q[i].opt[4] = "the first crossword puzzle appeared in 1913.";

    i++;
    q[i].category = "first";
    q[i].level=2;
    q[i].qn = "Who was the first person to produce the fist playing card?";
    q[i].opt[0] = "Nintendo";
    q[i].opt[1] = "Amanie";
    q[i].opt[2] = "Isaac Newton";
    q[i].opt[3] = "No one knows";
    q[i].correct_ans='1';
    q[i].opt[4] = "Nintendo first produced playing cards.";


///words
    i++;
    q[i].category = "words";
    q[i].level=2;
    q[i].qn = "How do we call a group of owls in English Language?";
    q[i].opt[0] = "Parliament";
    q[i].opt[1] = "Government";
    q[i].opt[2] = "A crew";
    q[i].opt[3] = "A scrand";
    q[i].correct_ans='1';
    q[i].opt[4] = "a group of owls is called a parliament.";

    i++;
    q[i].category = "words";
    q[i].level=2;
    q[i].qn = "How do we call a group of owls in English Language?";
    q[i].opt[0] = "Parliament";
    q[i].opt[1] = "A scoop";
    q[i].opt[2] = "A crew";
    q[i].opt[3] = "A gaggle";
    q[i].correct_ans='4';
    q[i].opt[4] = "a group of geese is called a gaggle.";

    i++;
    q[i].category = "words";
    q[i].level=2;
    q[i].qn = "How do we call a group of whales in English Language?";
    q[i].opt[0] = "Parliament";
    q[i].opt[1] = "Government";
    q[i].opt[2] = "A pod";
    q[i].opt[3] = "A gaggle";
    q[i].correct_ans='4';
    q[i].opt[4] = "a group of whales is called a pod.";

    i++;
    q[i].category = "words";
    q[i].level=2;
    q[i].qn = "How do we call a group of kangaroos in English Language?";
    q[i].opt[0] = "Parliament";
    q[i].opt[1] = "mob";
    q[i].opt[2] = "A pod";
    q[i].opt[3] = "A gaggle";
    q[i].correct_ans='2';
    q[i].opt[4] = "a group of kangaroos is called a mob.";

    return 0;
}

int demo(){
    system("cls");//clearing screen
    printf("\n\n\t\t--------->>> DEMO <<<<----------\n");
    printf("\n\t\t     Create a Player Account\n");
    printf("\n\t\t      Choose Player Account\n");
    printf("\n\t\t            Read ME\n");
    printf("\n\t\t              Quit        \n\n\t\t\t        ");


    here1:
    choice = getch();


    if(choice=='W' || choice=='w')
    {
        quiting();
        return 0;
    }
    else if(choice=='S' || choice=='s')
    {
        create_acc();
        return 0;
    }
    else if(choice==13)
    {
        system("cls");
        play(true);
        return 0;
    }else{
        goto here1;
    }
    //demo();
    return 0;
}



int create_acc(){
    //clearing screen
    system("cls");

    printf("\n\n\t\t             Demo\n");
    printf("\n\t      --->>> CREATE A PLAYER ACCOUNT <<<---\n");
    printf("\n\t              Choose Player Account\n");
    printf("\n\t\t            Read ME\n");
    printf("\n\t\t              Quit         \n\n\t\t\t        ");

    //waiting for choice from the user
    choice=getch();
    if(choice=='W' || choice=='w')
    {
        demo();
        return 0;
    }
    else if(choice=='S' || choice=='s')
    {
        choose_acc();
        return 0;
    }
    else if(choice==13){

    //NOW CREATING A PLAYER IN CASE THE USER PRSSES ENTER
        system("cls");
        printf("+---------------------------------+");
        printf("\n|   CREATING PLAYERS' ACCOUNTS    |");
        printf("\n|   --------------------------    |");
        printf("\n+---------------------------------+");


        player[number_of_players].display=1;
        fflush(stdin);
        printf("\n\n  PLAYER's NAME    :  ");


        fflush(stdin);
        choice = getche();
        cin>>player[number_of_players].name;


        while(1)
        {
            printf("\nWould you like to protect this account with a Key?\ntEnter 'Y' or 'y' for yes OR any key for no: ");
            choice=getch();
            if(choice=='y' || choice=='Y'){
                int m=0,q=0;
HERE:
                system("cls");
                fflush(stdin);
                printf("+---------------------------------+");
                printf("\n|   CREATING PLAYERS' ACCOUNTS    |");
                printf("\n|   --------------------------    |");
                printf("\n+---------------------------------+");


                printf("\n\n  PLAYER's NAME    :  ");
                cout<<player[number_of_players].name;
                fflush(stdin);

                printf("\n  ENTER SECRET KEY :  ");
                int l;
                if(l==100)
                {
                    for(q=0; q<m; q++)
                        printf("*"); //choice=getch();
                    l=0;
                }

                for(; m<25;)
                {
                    player[number_of_players].key[m]=getch();
                    if(player[number_of_players].key[m]==8)
                    {
                        if(m>0)
                            m--;
                        l=100;
                        goto HERE;
                    }
                    printf("*");
                    if(player[number_of_players].key[m]==13)
                    {
                        player[number_of_players].key[m]='\0';
                        //puts(player[number_of_players].key);
                        //choice=getch();
                        break;
                    }
                    m++;
                }

                fflush(stdin);
                int k;
                for(k=0; k<1000; k++)
                {
                    player[number_of_players].questions_answered[k]=0;
                }
                player[number_of_players].points=0;

                number_of_players++;
                printf("\n\n ACCOUNT CREATED SUCCESSFULLY");
                printf("\n YOUR SECRET KEY IS:  [ %s ]\n\n\t\t  ",player[number_of_players].key);
                choice=getch();
                break;
            }else{
                system("cls");
                number_of_players++;

                printf("\n\n ACCOUNT CREATED SUCCESSFULLY\n\n\t\t");

                choice=getch();
                break;
            }

        }
    }

    demo();
    return 0;
}



int quiting(){
    system("cls");//clearing screen

    printf("\n\n\t\t             Demo\n");
    printf("\n\t\t     Create a Player Account\n");
    printf("\n\t\t      Choose Player Account\n");
    printf("\n\t\t            Read ME\n");
    printf("\n\t\t  ------->>>> QUIT <<<<-------\n\n\t\t\t        ");

    //waiting for choice from the user
    choice=getch();
    if(choice=='W' || choice=='w')
    {
        read_me();
        return 0;
    }

    else if(choice=='S' || choice=='s')
    {
        demo();
        return 0;
    }
    else if(choice==13)
    {
        return 0;

    }
}


int choose_acc()
{

    system("cls");//clearing screen

    printf("\n\n\t\t             Demo\n");
    printf("\n\t\t     Create a Player Account\n");
    printf("\n\t\t--->> CHOOSE PLAYER ACCOUNT <<---\n");
    printf("\n\t\t            Read ME\n");
    printf("\n\t\t              Quit         \n\n\t\t\t        ");

    choice=getch();//waiting for choice from the user
    if(choice=='W' || choice=='w')
    {
        create_acc();
        return 0;
    }
    else if(choice=='S' || choice=='s')
    {
        read_me();
        return 0;
    }
    else if(choice==13)
    {
        printf("here You go");
    }

}

int read_me(){
    system("cls");//clearing screen

    printf("\n\n\t\t             Demo\n");
    printf("\n\t\t     Create a Player Account\n");
    printf("\n\t\t      Choose Player Account\n");
    printf("\n\t\t  ------>>> READ ME <<<------- \n");
    printf("\n\t\t              Quit        \n\n\t\t\t        ");

    choice=getch();//waiting for choice from the user

    if(choice=='W' || choice=='w')
    {
        choose_acc();
        return 0;
    }

    else if(choice=='S' || choice=='s')
    {
        quiting();
        return 0;
    }
    else if(choice==13)
    {
        printf("Reading me");
    }
    return 0;
}





